# -*- coding: utf-8 -*-
{
    'name': "Shopify Net Profit Report Ept",

    'summary': """
        Visible Net Profit report for shopify all instances.""",

    'description': """
        Visible Net Profit report for shopify all instances.
    """,

    'author': "Emipro Technologies Pvt. Ltd.",
    'website': "http://www.emiprotechnologies.com",

    'category': 'Account',
    'version': '0.1',

    'depends': ['account_reports', 'shopify_ept'],

    'data': [
        'report/net_profit_report.xml',
    ],
}
