from odoo import fields, models, api, _
from datetime import datetime, time
import pytz

try:
    from odoo.tools.misc import xlsxwriter
except ImportError:
    from odoo.addons.zs_customer_sales_analysis_report.library import xlsxwriter
import base64
from io import BytesIO
import logging

_logger = logging.getLogger(__name__)
from odoo.exceptions import UserError


class BranchConfigValueData(models.TransientModel):
    _name = 'branch.config.value.data'
    _description = 'Branch Storage Configuration Data'

    wizard_id = fields.Many2one('branch.value.config.report.wizard', string='Wizard', required=True, ondelete='cascade')
    company_id = fields.Many2one('res.company', string='Company', required=True)
    franchise_name = fields.Char(string='Franchise Division')
    division_name = fields.Char(string='Product Division')
    category_name = fields.Char(string='Category Name')
    brand_name = fields.Char(string='Brand Name')
    product_name = fields.Char(string='Product Name')
    barcode = fields.Char(string='Barcode')
    cost = fields.Char(string='Cost')
    range = fields.Char(string='Range')
    value_config_id = fields.Many2one('min.max.config', string='Value Configuration')
    reordering_id = fields.Many2one('stock.warehouse.orderpoint', string='Reordering Rule')
    basis_of_configuration = fields.Char(string='Basis of Configuration')
    min_qty = fields.Char(string='Min QTY')
    max_qty = fields.Char(string='Max QTY')


class BranchValueConfigurationReportWizard(models.TransientModel):
    _name = 'branch.value.config.report.wizard'

    file_data = fields.Binary('File Data')
    franchise_division_ids = fields.Many2many('product.company.type', string="Franchise Division")
    product_division_ids = fields.Many2many('product.division', string="Product Division")
    product_category_ids = fields.Many2many('product.category', string='Product Categories')
    product_brand_ids = fields.Many2many('product.brand', string='Product Brands')
    product_ids = fields.Many2many('product.product', string='Products')

    def action_view_pivot(self):
        self.populate_pivot_data()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Min Max Configuration By Value - Report',
            'res_model': 'branch.config.value.data',
            'view_mode': 'tree',
            'target': 'current',
            'domain': [('wizard_id', '=', self.id)],
        }

    def _get_data_for_products(self):
        rules = self.env['stock.warehouse.orderpoint'].search([('company_id', '=', self.env.company.id)])
        for rule in rules:
            rule._compute_product_min_max_qty()

        domain = []

        if self.franchise_division_ids:
            domain.append(('company_type', 'in', self.franchise_division_ids.ids))

        if self.product_division_ids:
            domain.append(('product_division_id', 'in', self.product_division_ids.ids))

        if self.product_category_ids:
            domain.append(('categ_id', 'in', self.product_category_ids.ids))

        if self.product_brand_ids:
            domain.append(('product_brand_id', 'in', self.product_brand_ids.ids))

        if self.product_ids:
            domain.append(('id', 'in', self.product_ids.ids))

        products = self.env['product.product'].search(domain)
        products_dict = []
        for product in products:
            min_qty = "N/A"
            max_qty = "N/A"

            reordering_rule = self.env['stock.warehouse.orderpoint'].search(
                [('product_id', '=', product.id), ('company_id', '=', self.env.company.id)], limit=1)

            range = ""
            if product.value_config_id:
                if product.value_config_id.product_id:
                    min_qty = product.value_config_id.min_qty
                    max_qty = product.value_config_id.max_qty
                else:
                    line = product.value_config_id.child_ids.filtered(
                        lambda l: l.min_price <= product.standard_price <= l.max_price)[:1]
                    if line:
                        range = f"{line.min_price}-{line.max_price}"
                        min_qty = line.min_qty
                        max_qty = line.max_qty
                    else:
                        range = ""
            else:
                range = ""
            products_dict.append({
                'product_name': product.name,
                'brand_name': product.product_brand_id.name,
                'category_name': product.categ_id.name,
                'franchise_name': product.company_type.name,
                'division_name': product.product_division_id.name,
                'barcode': product.barcode,
                'cost': product.standard_price,
                'reordering_id': reordering_rule.id,
                'value_config_id': product.value_config_id.id,
                'basis_of_configuration': product.value_config_basis,
                'min_qty': min_qty,
                'max_qty': max_qty,
                "range": range,
                "company_id": self.env.company.id,
            })
        return products_dict

    def populate_pivot_data(self):
        products_data = self._get_data_for_products()
        pivot_model = self.env['branch.config.value.data']
        pivot_model.search([('company_id', '=', self.env.company.id)]).unlink()
        for product_data in products_data:
            pivot_model.create({
                'wizard_id': self.id,
                'product_name': product_data['product_name'],
                'franchise_name': product_data['franchise_name'],
                'division_name': product_data['division_name'],
                'category_name': product_data['category_name'],
                'brand_name': product_data['brand_name'],
                'barcode': product_data['barcode'],
                'cost': product_data['cost'],
                'reordering_id': product_data['reordering_id'],
                'value_config_id': product_data['value_config_id'],
                'basis_of_configuration': product_data['basis_of_configuration'],
                'min_qty': product_data['min_qty'],
                'max_qty': product_data['max_qty'],
                'range': product_data['range'],
                'company_id': product_data['company_id'],
            })
